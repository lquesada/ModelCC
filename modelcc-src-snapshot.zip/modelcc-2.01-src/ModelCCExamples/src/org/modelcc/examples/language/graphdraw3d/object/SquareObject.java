// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.graphdraw3d.object;

import org.modelcc.examples.language.graphdraw3d.SceneObject;
import static org.lwjgl.opengl.GL11.*;
import org.modelcc.*;
import org.modelcc.examples.language.graphdraw3d.resources.RunData;
import org.modelcc.examples.language.graphdraw3d.resources.TextureData;

/**
 * Axis.
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Pattern(regExp="square")
public final class SquareObject extends SceneObject implements IModel {

    @Override
    public void draw(RunData rd) {
        TextureData texin = rd.getCurrentTexture();
        glBegin(GL_QUADS);
        glTexCoord2f(texin.getX2(),texin.getY2());
        glVertex3f(-0.5f,-0.5f,0.f);
        glTexCoord2f(texin.getX1(),texin.getY2());
        glVertex3f(-0.5f,+0.5f,0.f);
        glTexCoord2f(texin.getX1(),texin.getY1());
        glVertex3f(+0.5f,+0.5f,0.f);
        glTexCoord2f(texin.getX2(),texin.getY1());
        glVertex3f(+0.5f,-0.5f,0.f);

        glTexCoord2f(texin.getX1(),texin.getY1());
        glVertex3f(+0.5f,+0.5f,0.f);
        glTexCoord2f(texin.getX1(),texin.getY2());
        glVertex3f(-0.5f,+0.5f,0.f);
        glTexCoord2f(texin.getX2(),texin.getY2());
        glVertex3f(-0.5f,-0.5f,0.f);
        glTexCoord2f(texin.getX2(),texin.getY1());
        glVertex3f(+0.5f,-0.5f,0.f);
        
        glEnd();
    }
    
}
