// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.imperativearithmetic.expressions;

import org.modelcc.examples.language.imperativearithmetic.Expression;
import org.modelcc.examples.language.imperativearithmetic.UnaryOperator;
import org.modelcc.*;

/**
 * @author Luis Quesada (lquesada@modelcc.org)
 */
public class UnaryExpression extends Expression implements IModel {
    
    private UnaryOperator op;
    
    private Expression e;

    @Override
    public double eval() {
        return op.eval(e);
    }
}
