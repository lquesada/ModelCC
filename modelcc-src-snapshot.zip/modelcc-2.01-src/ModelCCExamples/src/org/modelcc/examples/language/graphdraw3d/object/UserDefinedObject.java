// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.graphdraw3d.object;

import org.modelcc.examples.language.graphdraw3d.SceneObject;
import org.modelcc.*;
import org.modelcc.examples.language.graphdraw3d.Definition;
import org.modelcc.examples.language.graphdraw3d.ObjectName;
import org.modelcc.examples.language.graphdraw3d.resources.RunData;

/**
 * Axis.
 * @author Luis Quesada (lquesada@modelcc.org)
 */
public final class UserDefinedObject extends SceneObject implements IModel {

    @Reference
    Definition object;
    
    @Override
    public void draw(RunData rd) {
        object.run(rd);
    }
    
    @Override
    public ObjectName getName() {
        return object.getName();
    }
    
}
