// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.canvasdraw.graphicelement;

import java.awt.Graphics;
import java.util.List;
import org.modelcc.*;
import org.modelcc.examples.language.canvasdraw.Coordinates;
import org.modelcc.examples.language.canvasdraw.GraphicElement;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Prefix("polygon")
public class Polygon extends GraphicElement implements IModel {

    @Prefix("\\[")
    @Suffix("\\]")
    @Minimum(3)
    List<Coordinates> coords;
    
    @Optional
    Fill fill;
    
    @Override
    public void paint(Graphics g) {
        int x[] = new int[coords.size()];
        int y[] = new int[coords.size()];
        int n = coords.size();
        for (int i = 0;i < n;i++) {
            x[i] = coords.get(i).getX().getValue();
            y[i] = coords.get(i).getY().getValue();
        }
        if (fill != null)
            g.fillPolygon(x,y,n);
        else
            g.drawPolygon(x,y,n);
    }
}
