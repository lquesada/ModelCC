// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.graphdraw3d.sentence;

import static org.lwjgl.opengl.GL11.*;
import org.modelcc.*;
import org.modelcc.examples.language.graphdraw3d.resources.RunData;
import org.modelcc.examples.language.graphdraw3d.Sentence;
import org.modelcc.examples.language.graphdraw3d.resources.ColorData;
import org.modelcc.examples.language.graphdraw3d.resources.TextureData;

/**
 * Block Sentence
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Prefix("\\{")
@Suffix("\\}")
public final class BlockSentence extends Sentence implements IModel {
    
    @Minimum(0)
    Sentence[] sentences;

    @Override
    public void run(RunData rd) {
        ColorData cd = rd.getCurrentColor();
        TextureData td = rd.getCurrentTexture();
        glPushMatrix();
        for (int i = 0;i < sentences.length;i++)
            sentences[i].run(rd);
        glPopMatrix();
        rd.setCurrentColor(cd);
        rd.setCurrentTexture(td);
    }
        
}
