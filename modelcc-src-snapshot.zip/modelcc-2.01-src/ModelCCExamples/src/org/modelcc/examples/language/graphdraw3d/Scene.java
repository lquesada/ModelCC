// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.graphdraw3d;

import org.modelcc.examples.language.graphdraw3d.resources.TextureData;
import org.modelcc.*;
import org.modelcc.examples.language.graphdraw3d.resources.ColorData;
import org.modelcc.examples.language.graphdraw3d.resources.Resources;
import org.modelcc.examples.language.graphdraw3d.resources.RunData;

/**
 * 3D Graph scene.
 * @author Luis Quesada (lquesada@modelcc.org)
 */
public final class Scene implements IModel {
    
    @Optional
    Definition[] definitions;
            
    @Prefix("scene")
    Sentence sceneContent;
    
    public void draw() {
        ColorData black = new ColorData(0.5,0.5,0.5,0.5);
        TextureData grass = Resources.getTextures()[0];
        black.draw();
        RunData rd = new RunData(black,grass);
        sceneContent.run(rd);
    }
    
}
