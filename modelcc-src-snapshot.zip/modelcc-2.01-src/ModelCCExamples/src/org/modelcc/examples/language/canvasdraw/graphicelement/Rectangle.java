// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.canvasdraw.graphicelement;

import org.modelcc.*;
import org.modelcc.examples.language.canvasdraw.Coordinates;
import org.modelcc.examples.language.canvasdraw.GraphicElement;
import java.awt.*;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Prefix("rectangle")
public class Rectangle extends GraphicElement implements IModel {
    
    @Minimum(2)
    @Maximum(2)
    @Prefix("\\[")
    @Suffix("\\]")
    Coordinates[] coords;

    @Optional
    Fill fill;
   
    @Override
    public void paint(Graphics g) {
        int x1 = coords[0].getX().getValue();
        int y1 = coords[0].getY().getValue();
        int x2 = coords[1].getX().getValue();
        int y2 = coords[1].getY().getValue();
        int x,y,w,h;
        if (x1<x2) {
            x = x1;
            w = x2-x1;
        }
        else {
            x = x2;
            w = x1-x2;
        }
        if (y1<y2) {
            y = y1;
            h = y2-y1;
        }
        else {
            y = y2;
            h = y1-y2;
        }
        if (fill != null)
            g.fillRect(x,y,w,h);
        else
            g.drawRect(x,y,w,h);
    }
}
