// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.graphdraw3d.sentence;

import org.modelcc.*;
import org.modelcc.examples.language.graphdraw3d.IntegerLiteral;
import org.modelcc.examples.language.graphdraw3d.resources.RunData;
import org.modelcc.examples.language.graphdraw3d.Sentence;

/**
 * Block Sentence
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Prefix("repeat")
public final class RepeatSentence extends Sentence implements IModel {
    
    @Suffix("times")
    IntegerLiteral times;

    Sentence sentence;

    @Override
    public void run(RunData rd) {
        for (int i = 0;i < times.intValue();i++) {
            sentence.run(rd);
        }
    }
    
}
