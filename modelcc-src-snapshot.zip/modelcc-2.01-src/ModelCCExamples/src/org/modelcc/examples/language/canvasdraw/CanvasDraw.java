// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.canvasdraw;

import org.modelcc.*;

import java.awt.*;
import javax.swing.JComponent;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Prefix("canvas")
public class CanvasDraw extends JComponent implements IModel {
    
    public Parameters pars;
    
    @Minimum(0)
    public GraphicElement[] elems;    
    
    int width;
    int height;
    Color background;

    @Autorun
    public void open() {
        width = 640;
        height = 480;
        background = new Color(255,255,255);
        if (pars.getBackground() != null)
            background = pars.getBackground().getColor();
        if (pars.getWidth() != null)
            width = pars.getWidth().getValue();
        if (pars.getHeight() != null)
            height = pars.getHeight().getValue();
        setSize(width,height);
        setBackground(background);
        setVisible(true);
        setDoubleBuffered(true);
    }
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(background);
        g.fillRect(0,0,getWidth(),getHeight());
        g.setColor(new Color(0,0,0));
        ((Graphics2D)g).setStroke(new BasicStroke(1f));

        if (elems != null) {
            for (int i = 0;i < elems.length;i++) {
                elems[i].paint(g);
            }
        }
    }
    
}
