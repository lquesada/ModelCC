// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.graphdraw3d;

import org.modelcc.*;

/**
 * Object Name
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Pattern(regExp="[A-Za-z][a-zA-Z0-9_]*")
public final class ObjectName implements IModel {
        
    @Value String name;

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ObjectName other = (ObjectName) obj;
        if ((this.name == null) ? (other.name != null) : !this.name.equals(other.name)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + (this.name != null ? this.name.hashCode() : 0);
        return hash;
    }
    
    @Autorun
    public boolean build() {
        if (name.equals("axis") || name.equals("cube") || name.equals("square"))
            return false;
        return true;
    }
    
    @Override
    public String toString() {
        return name;
    }
    
}
