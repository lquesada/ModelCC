// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.graphdraw3d.resources;

import static org.lwjgl.opengl.GL11.*;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
public class ColorData {

    private double r;
    private double g;
    private double b;
    private double a;

    public ColorData(double r,double g,double b,double a) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;

        if (r<0.0)
            r = 0.0;
        if (r>1.0)
            r = 1.0;
        if (g<0.0)
            g = 0.0;
        if (g>1.0)
            g = 1.0;
        if (b<0.0)
            b = 0.0;
        if (b>1.0)
            b = 1.0;
        if (a<0.0)
            a = 0.0;
        if (a>1.0)
            a = 1.0;
    }

    /**
     * @return the r
     */
    public double getR() {
        return r;
    }

    /**
     * @return the g
     */
    public double getG() {
        return g;
    }

    /**
     * @return the b
     */
    public double getB() {
        return b;
    }

    /**
     * @return the a
     */
    public double getA() {
        return a;
    }

    public void draw() {
        glColor4d(r,g,b,a);
    }
    
}
