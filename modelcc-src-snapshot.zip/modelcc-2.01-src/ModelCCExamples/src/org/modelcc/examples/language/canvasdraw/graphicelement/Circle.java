// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.examples.language.canvasdraw.graphicelement;

import org.modelcc.*;
import org.modelcc.examples.language.canvasdraw.Coordinates;
import org.modelcc.examples.language.canvasdraw.GraphicElement;
import org.modelcc.examples.language.canvasdraw.Numeric;
import java.awt.*;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Prefix("circle")
public class Circle extends GraphicElement implements IModel {

    Coordinates coords;
    
    @Prefix(",")
    Numeric radius;

    @Optional
    Fill fill;
    
    @Override
    public void paint(Graphics g) {
        int x = coords.getX().getValue();
        int y = coords.getY().getValue();
        int r = radius.getValue();
        if (fill != null)
            g.fillOval(x-r,y-r,r*2,r*2);
        else
            g.drawOval(x-r,y-r,r*2,r*2);
    }
}
