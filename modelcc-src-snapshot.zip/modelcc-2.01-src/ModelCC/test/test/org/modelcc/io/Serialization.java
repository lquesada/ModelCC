// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package test.org.modelcc.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import test.org.modelcc.io.java.JavaModelReaderTest;
import static org.junit.Assert.*;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
public abstract class Serialization {
    
    public static Object testSerialize(Object o) throws ClassNotFoundException {
        if (o == null)
            return null;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(out);
            oos.writeObject(o);
            oos.close();
        } catch (Exception e) {
            Logger.getLogger(JavaModelReaderTest.class.getName()).log(Level.SEVERE, null, e);
            assertTrue(false);
        }
        assertTrue(out.toByteArray().length > 0);
        
        byte[] pickled = out.toByteArray();
        InputStream in = new ByteArrayInputStream(pickled);
        ObjectInputStream ois;
        Object o2 = null;
        try {
            ois = new ObjectInputStream(in);
            o2 = ois.readObject();
        } catch (IOException ex) {
            Logger.getLogger(JavaModelReaderTest.class.getName()).log(Level.SEVERE, null, ex);
             assertTrue(false);
       }

        return o;
    }
    
}
