// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package test.languages.extra;

import org.modelcc.*;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Pattern(regExp="\\(\\+")
public class ParenthesisPlus implements IModel {

}
