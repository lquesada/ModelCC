// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package test.languages.keys;

import org.modelcc.*;

/**
 *
 * @author Luis Quesada (lquesada@modelcc.org)
 */
public class Keys4Lang implements IModel {

    @Optional
    @Reference public Keys1 refs;
    
    @Prefix("data") 
    public Keys1[] keys1;
    
    
}
