// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package test.languages.arithmeticcalculator2.binaryoperators;

import test.languages.arithmeticcalculator2.BinaryOperator;
import test.languages.arithmeticcalculator2.Expression2;
import org.modelcc.*;

/**
 * @author Luis Quesada (lquesada@modelcc.org)
 */
@Priority(value=5)
@Pattern(regExp="-")
public class SubstractionOperator extends BinaryOperator implements IModel {

    @Override
    public double eval(Expression2 e1, Expression2 e2) {
        return e1.eval()-e2.eval();
    }

}
