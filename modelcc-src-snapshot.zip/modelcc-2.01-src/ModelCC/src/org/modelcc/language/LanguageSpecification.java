// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language;

import java.io.Serializable;
import org.modelcc.language.lexis.LexicalSpecification;
import org.modelcc.language.syntax.SyntacticSpecification;

/**
 * Language specification.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class LanguageSpecification implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Lexical specification.
     */
    private LexicalSpecification lexicalSpecification;

    /**
     * Syntactic specification.
     */
    private SyntacticSpecification syntacticSpecification;

    /**
     * Constructor
     * @param lexicalSpecification the lexical specification.
     * @param syntacticSpecification the syntactic specification.
     */
    public LanguageSpecification(LexicalSpecification lexicalSpecification,SyntacticSpecification syntacticSpecification) {
        this.lexicalSpecification = lexicalSpecification;
        this.syntacticSpecification = syntacticSpecification;
    }

    /**
     * @return the lexicalSpecification
     */
    public LexicalSpecification getLexicalSpecification() {
        return lexicalSpecification;
    }

    /**
     * @return the syntacticSpecification
     */
    public SyntacticSpecification getSyntacticSpecification() {
        return syntacticSpecification;
    }

}
