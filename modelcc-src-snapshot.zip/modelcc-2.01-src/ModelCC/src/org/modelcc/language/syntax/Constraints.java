// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language.syntax;

import java.io.Serializable;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

/**
 * Syntactic constraints.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class Constraints implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Map of associativities.
     */
    private Map<Object,AssociativityConstraint> associativities;

    /**
     * Map of composition precedences.
     */
    private Map<Rule, Set<Rule>> compositionPrecedences;

    /**
     * Map of selection precedences.
     */
    private Map<Rule, Set<Rule>> selectionPrecedences;

    /**
     * Constructor.
     * @param associativities the elements associativities.
     * @param compositionPrecedences the map of content precedences.
     * @param selectionPrecedences the map of selection precedences.
     */
    public Constraints(Map<Object,AssociativityConstraint> associativities, Map<Rule,Set<Rule>> compositionPrecedences,Map<Rule, Set<Rule>> selectionPrecedences) {
        this.associativities = associativities;
        this.compositionPrecedences = compositionPrecedences;
        this.selectionPrecedences = selectionPrecedences;
    }

    /**
     * @return the object associativities.
     */
    public Map<Object,AssociativityConstraint> getAssociativities() {
        return Collections.unmodifiableMap(associativities);
    }

    /**
     * @return the composition precedences
     */
    public Map<Rule, Set<Rule>> getCompositionPrecedences() {
        return Collections.unmodifiableMap(compositionPrecedences);
    }

    /**
     * @return the selection precedences
     */
    public Map<Rule, Set<Rule>> getSelectionPrecedences() {
        return Collections.unmodifiableMap(selectionPrecedences);
    }

}
