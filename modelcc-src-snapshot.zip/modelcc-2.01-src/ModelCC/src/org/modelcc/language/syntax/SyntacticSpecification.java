// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language.syntax;

import java.io.Serializable;

/**
 * Syntactic specification.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class SyntacticSpecification implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Grammar.
     */
    private Grammar grammar;

    /**
     * Constraints.
     */
    private Constraints constraints;

    /**
     * Constructor.
     */
    public SyntacticSpecification() {
        this.grammar = null;
        this.constraints = null;
    }

    /**
     * Constructor.
     * @param grammar the grammar.
     * @param constraints the constraints.
     */
    public SyntacticSpecification(Grammar grammar,Constraints constraints) {
        this.grammar = grammar;
        this.constraints = constraints;
    }

    /**
     * @return the grammar
     */
    public Grammar getGrammar() {
        return grammar;
    }

    /**
     * @param grammar the grammar to set
     */
    public void setGrammar(Grammar grammar) {
        this.grammar = grammar;
    }

    /**
     * @return the constraints
     */
    public Constraints getConstraints() {
        return constraints;
    }

    /**
     * @param constraints the constraints to set
     */
    public void setConstraints(Constraints constraints) {
        this.constraints = constraints;
    }
}
