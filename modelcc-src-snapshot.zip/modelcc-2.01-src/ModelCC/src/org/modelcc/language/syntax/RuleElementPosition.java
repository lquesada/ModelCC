// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language.syntax;

import java.io.Serializable;

/**
 * Rule element position.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class RuleElementPosition extends RuleElement implements Serializable {
    
    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Id of the element. Can be user defined to identify the position of the matching tokens.
     */
    private Object positionId;

    /**
     * Constructor.
     * @param type the type of the rule element.
     * @param positionId the position id.
     */
    public RuleElementPosition(Object type,Object positionId) {
        super(type);
        this.positionId = positionId;
    }

    /**
     * @return the id
     */
    public Object getPositionId() {
        return positionId;
    }

    /**
     * @param positionId the id to set
     */
    public void setPositionId(Object positionId) {
        this.positionId = positionId;
    }

}
