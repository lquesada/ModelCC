// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language.factory;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.modelcc.parser.fence.Symbol;


/**
 * ModelCC Parser Data.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class ModelCCParserData implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * ID maps.
     */
    private Map<Class,Map<KeyWrapper,Object>> ids;

    /**
     * Object map.
     */ 
    private Map<Object,ObjectWrapper> map;
          
    /**
     * The lazy references set.
     */
    private Set<Symbol> lazyReferences;
    
    /**
     * Constructor.
     */
    public ModelCCParserData() {
        ids = new HashMap<Class,Map<KeyWrapper,Object>>();
        map = new HashMap<Object,ObjectWrapper>();
        lazyReferences = new HashSet<Symbol>();
    }

    /**
     * @return the ids
     */
    public Map<Class,Map<KeyWrapper,Object>> getIds() {
        return ids;
    }

    /**
     * @return the map
     */
    public Map<Object,ObjectWrapper> getMap() {
        return map;
    }

    /**
     * @return the lazyReferences
     */
    public Set<Symbol> getLazyReferences() {
        return lazyReferences;
    }
    
}