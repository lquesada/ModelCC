// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language.factory;

import java.io.Serializable;
import java.util.Map;
import org.modelcc.language.syntax.SymbolBuilder;
import org.modelcc.metamodel.Model;
import org.modelcc.parser.fence.Symbol;

/**
 * Symbol content builder
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class TokenSymbolBuilder extends SymbolBuilder implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * The model.
     */
    private Model m;
    
    /**
     * Constructor
     * @param m the model.
     */
    public TokenSymbolBuilder(Model m) {
        this.m = m;
    }
    
    /**
     * Builds a token symbol.
     * @param t symbol to be built.
     * @param data the parser listData.
     * @return true if the symbol is valid, false if not
     */
    public boolean build(Symbol t,Object data) {
        Map<Object,ObjectWrapper> map = ((ModelCCParserData)data).getMap();
        map.put(t.getUserData(),new ObjectWrapper(t.getUserData(),m,t.getParsedSymbol().getString().hashCode(),t.getParsedSymbol().getString()));
        return true;
    }
}
