// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language.factory;

import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.modelcc.language.syntax.SymbolBuilder;
import org.modelcc.metamodel.ModelElement;
import org.modelcc.parser.fence.Symbol;

/**
 * Symbol inherit builder
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class DecoratorSymbolBuilder extends SymbolBuilder implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Builds a symbol, filling its data, and validates it.
     * @param t symbol to be built.
     * @param data the parser data.
     * @return true if the symbol is valid, false if not
     */
    public boolean build(Symbol t,Object data) {
        ElementId eid = (ElementId)t.getType();
        ModelElement el = eid.getElement();
        Object o = null;
        boolean valid = true;

        int target = -1;
        for (int i = 0;i < t.getContents().size();i++) {
            if (t.getContents().get(i).getType().getClass().equals(ElementId.class))
                target = i;
        }

        try {
            if (target != -1) {
                o = t.getContents().get(target).getUserData();
            }

            t.setUserData(o);

        } catch (Exception ex) {
            Logger.getLogger(DecoratorSymbolBuilder.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

        return valid;
    }
}
