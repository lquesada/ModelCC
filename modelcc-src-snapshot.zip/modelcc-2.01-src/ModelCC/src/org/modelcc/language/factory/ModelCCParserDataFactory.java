// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.language.factory;

import org.modelcc.language.syntax.*;
import java.io.Serializable;


/**
 * ModelCC Parser Data Factory.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class ModelCCParserDataFactory extends ParserDataFactory implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Generate a parser data object.
     * @return the parser data object.
     */
    public Object generate() {
        return new ModelCCParserData();
    }
    
}