// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.io;

import java.util.logging.Filter;
import java.util.logging.LogRecord;

/**
 * A filter that filters everything.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class DefaultFilter implements Filter {
    
    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    public boolean isLoggable(LogRecord record) {
        return true;
    }

}
