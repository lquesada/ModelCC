// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.lexer;

import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import org.modelcc.lexer.lamb.LexicalGraph;

/**
 * ModelCC Lexer
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public abstract class Lexer implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Scans an input reader.
     * @param input the input reader.
     * @return the obtained lexical graph.
     */
    public abstract LexicalGraph scan(Reader input);
    
    /**
     * Scans an input string.
     * @param input the input string.
     * @return the obtained lexical graph.
     */
    public LexicalGraph scan(String input) {
        return scan(new StringReader(input));
    }

}
