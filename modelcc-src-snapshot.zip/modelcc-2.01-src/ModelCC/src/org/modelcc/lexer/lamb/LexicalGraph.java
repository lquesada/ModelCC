// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.lexer.lamb;

import java.util.Collections;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

/**
 * Lexical Graph.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class LexicalGraph implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * List of start tokens of this graph.
     */
    Set<Token> tokens;

    /**
     * List of start tokens of this graph.
     */
    Set<Token> start;

    /**
     * List of preceding tokens.
     */
    Map<Token,Set<Token>> preceding;

    /**
     * List of following tokens.
     */
    Map<Token,Set<Token>> following;

    /**
     * Input start index
     */
    int inputstart;

    /**
     * Input end index
     */
    int inputend;
    
    /**
     * Default constructor.
     * @param tokens the token set
     * @param start the start symbol
     * @param preceding the preceding map
     * @param following the following map
     */
    public LexicalGraph(Set<Token> tokens,Set<Token> start,Map<Token,Set<Token>> preceding,Map<Token,Set<Token>> following,int inputstart,int inputend) {
        this.tokens = tokens;
        this.start = start;
        this.preceding = preceding;
        this.following = following;
        this.inputstart = inputstart;
        this.inputend = inputend;
    }

    /**
     * @return the start tokens of this graph.
     */
    public Set<Token> getStart() {
        return Collections.unmodifiableSet(start);
    }

    /**
     * @return the tokens used in this graph.
     */
    public Set<Token> getTokens() {
        return Collections.unmodifiableSet(tokens);
    }

    /**
     * @return the map of precedings.
     */
    public Map<Token, Set<Token>> getPreceding() {
        return Collections.unmodifiableMap(preceding);
    }

    /**
     * @return the map of following.
     */
    public Map<Token, Set<Token>> getFollowing() {
        return Collections.unmodifiableMap(following);
    }

    /**
     * @return the input start index.
     */
    public int getInputStart() {
        return inputstart;
    }

    /**
     * @return the input end index.
     */
    public int getInputEnd() {
        return inputend;
    }

}
