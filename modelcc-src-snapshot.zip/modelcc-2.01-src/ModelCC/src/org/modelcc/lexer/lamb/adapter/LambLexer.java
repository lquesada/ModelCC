// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.lexer.lamb.adapter;

import org.modelcc.lexer.lamb.*;
import java.io.Reader;
import java.io.Serializable;
import java.util.Set;
import org.modelcc.language.lexis.LexicalSpecification;
import org.modelcc.lexer.Lexer;
import org.modelcc.lexer.recognizer.PatternRecognizer;

/**
 * Lamb - SyntaxGraphLexer with AMBiguity Support.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class LambLexer extends Lexer implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Lexical Specification.
     */
    private LexicalSpecification ls;
    
    /**
     * Ignore pattern set.
     */
    private Set<PatternRecognizer> ignore;

    /**
     * Constructor.
     * @param ls the lexical specification.
     */
    public LambLexer(LexicalSpecification ls) {
        this.ls = ls;
        this.ignore = null;
    }
    
    /**
     * Constructor.
     * @param ls the lexical specification.
     * @param ignore the ignore pattern set.
     */
    public LambLexer(LexicalSpecification ls,Set<PatternRecognizer> ignore) {
        this.ls = ls;
        this.ignore = ignore;
    }
    
    /**
     * Scans an input string.
     * @param input the input string.
     * @return the obtained lexical graph.
     */    
    @Override
    public LexicalGraph scan(Reader input) {
        Lamb gl = new Lamb();
        LexicalGraph sg = gl.scan(ls,ignore,input);
        return sg;
    }

}