// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.lexer.lamb;

import java.io.Serializable;

/**
 * Token.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class Token implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Token type.
     */
    private Object type;

    /**
     * Value.
     */
    private Object value;

    /**
     * Start index.
     */
    private int startIndex;

    /**
     * End index.
     */
    private int endIndex;

    /**
     * User data.
     */
    private Object userData;

    /**
     * matched text string.
     */
    private CharSequence string;
    
    /**
     * Constructor.
     * @param type the token type.
     * @param value the value.
     * @param startIndex the startIndex index.
     * @param endIndex the endIndex index.
     * @param string the matched string. 
     */
    public Token(Object type,Object value,int startIndex,int endIndex,CharSequence string) {
        this.type = type;
        this.value = value;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.string = string;
    }

    /**
     * @return the token type.
     */
    public Object getType() {
        return type;
    }

    /**
     * @return the value.
     */
    public Object getValue() {
        return value;
    }

    /**
     * @return the startIndex index.
     */
    public int getStartIndex() {
        return startIndex;
    }

    /**
     * @return the endIndex index.
     */
    public int getEndIndex() {
        return endIndex;
    }

    /**
     * @param value the value to set
     */
    public void setValue(Object value) {
        this.value = value;
    }

    /**
     * @return the userData
     */
    public Object getUserData() {
        return userData;
    }

    /**
     * @param userData the userData to set
     */
    public void setUserData(Object userData) {
        this.userData = userData;
    }

    /**
     * @return the string
     */
    public CharSequence getString() {
        return string;
    }

}
