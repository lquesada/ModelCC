// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.metamodel;

import java.util.List;
import org.modelcc.lexer.recognizer.PatternRecognizer;
import org.modelcc.AssociativityType;

/**
 * Select element.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class ChoiceModelElement extends ModelElement {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Constructor.
     * @param elementClass the element class
     * @param associativity the associativity
     * @param prefix the prefix
     * @param suffix the suffix
     * @param separator the default separator
     * @param AutorunMethod the run on load method
     * @param hasAnyAssociativity has any associativity 
     */
    public ChoiceModelElement(Class elementClass,AssociativityType associativity,List<PatternRecognizer> prefix,List<PatternRecognizer> suffix,List<PatternRecognizer> separator,String AutorunMethod,boolean hasAnyAssociativity) {
        super(elementClass,associativity,prefix,suffix,separator,AutorunMethod,hasAnyAssociativity);
    }

    
}
