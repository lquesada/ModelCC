// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.metamodel;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.modelcc.lexer.recognizer.PatternRecognizer;
import org.modelcc.AssociativityType;
import org.modelcc.CompositionType;

/**
 * Composite element.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class ComplexModelElement extends ModelElement {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * ModelElement contents.
     */
    private List<ElementMember> contents;

    /**
     * ModelElement ids.
     */
    private List<ElementMember> ids;

    /**
     * Whether if the element can be placed in free order.
     */
    private boolean freeOrder;

    /**
     * Composition type.
     */
    private CompositionType composition;

    /**
     * Field to ElementMember.
     */
    private Map<String,ElementMember> fieldToContent;

    /**
     * Constructor.
     * @param elementClass the element class
     * @param associativity the associativity
     * @param prefix the prefix
     * @param suffix the suffix
     * @param separator the default separator
     * @param AutorunMethod the run on load method
     * @param contents the element contents
     * @param ids the element ids
     * @param freeOrder whether if the element may be placed in free order
     * @param composition the composition type
     * @param hasAnyAssociativity has any associativity 
     */
    public ComplexModelElement(Class elementClass,AssociativityType associativity,List<PatternRecognizer> prefix,List<PatternRecognizer> suffix,List<PatternRecognizer> separator,String AutorunMethod,List<ElementMember> contents,List<ElementMember> ids,boolean freeOrder,CompositionType composition,boolean hasAnyAssociativity) {
        super(elementClass,associativity,prefix,suffix,separator,AutorunMethod,hasAnyAssociativity);
        this.contents = contents;
        this.ids = ids;
        this.freeOrder = freeOrder;
        this.composition = composition;
        fieldToContent = new HashMap<String,ElementMember>();
        ElementMember ct;
        for (Iterator<ElementMember> ite = contents.iterator();ite.hasNext();) {
            ct = ite.next();
            fieldToContent.put(ct.getField(),ct);
        }
    }

    /**
     * @return the contents
     */
    public List<ElementMember> getContents() {
        return Collections.unmodifiableList(contents);
    }

    /**
     * @return the ids
     */
    public List<ElementMember> getIds() {
        return Collections.unmodifiableList(ids);
    }

    /**
     * @return whether if this element can be freeOrder
     */
    public boolean isFreeOrder() {
        return freeOrder;
    }

    /**
     * @return the composition
     */
    public CompositionType getComposition() {
        return composition;
    }

    /**
     * @return the fieldToContent
     */
    public Map<String, ElementMember> getFieldToContent() {
        return Collections.unmodifiableMap(fieldToContent);
    }

    
}
