// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.parser;

import java.io.Serializable;

/**
 * CannotCreateParser Exception
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public class CannotCreateParserException extends Exception implements Serializable {
    
    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Chained exception.
     */
    Exception e;

    /**
     * Constructor.
     * @param e the chained exception.
     */
    public CannotCreateParserException(Exception e) {
        this.e = e;
    }

    /**
     * Print stack trace.
     */
    @Override
    public void printStackTrace() {
        System.out.println(this.getClass().getName()+" -> "+e.getClass().getName());
        e.printStackTrace();
    }

}
