// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.parser.fence.adapter;

import java.io.Reader;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.modelcc.language.syntax.SyntacticSpecification;
import org.modelcc.parser.Parser;
import org.modelcc.lexer.Lexer;
import org.modelcc.parser.fence.Symbol;
import org.modelcc.parser.fence.SyntaxGraph;
import org.modelcc.parser.fence.Fence;

/**
 * ModelCC FenceParser
 * @param <T> the results type of the parser
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public class FenceParser<T> extends Parser implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * The generic parser.
     */
    private Fence gp;

    /**
     * The generic lexer.
     */
    private Lexer gl;

    /**
     * The syntactic specification.
     */
    private SyntacticSpecification ls;

    /**
     * Constructor
     * @param gl the generic lexer
     * @param gp the generic parser
     * @param ls the language specification
     */
    public FenceParser(Lexer gl,Fence gp,SyntacticSpecification ls) {
        this.gl = gl;
        this.gp = gp;
        this.ls = ls;
    }

    /**
     * Parses an input string
     * @param input the input string
     * @return a collection of parsed objects
     */
    @Override
     public Collection<T> parseAll(Reader input) {
        SyntaxGraph sg = gp.parse(ls,gl.scan(input));
        Set<T> out = new HashSet<T>();
        for (Iterator<Symbol> ite = sg.getRoots().iterator();ite.hasNext();) {
            out.add((T)ite.next().getUserData());
        }
        return out;
    }

    /**
     * Parses an input string
     * @param input the input string
     * @return a parsed object
     */
    @Override
    public T parse(String input) {
        Iterator<T> ite = parseIterator(input);
        if (ite.hasNext())
            return ite.next();
        else
            return null;
    }

    /**
     * Parses an input reader
     * @param input the input reader
     * @return a parsed object
     */
    @Override
    public T parse(Reader input) {
        return parseIterator(input).next();
    }

    /**
     * Parses an input string
     * @param input the input string
     * @return an iterator to the collection of parsed objects
     */
    @Override
    public Iterator<T> parseIterator(String input) {
        return parseAll(input).iterator();
    }

    /**
     * Parses an input reader
     * @param input the input reader
     * @return an iterator to the collection of parsed objects
     */
    @Override
    public Iterator<T> parseIterator(Reader input) {
        return parseAll(input).iterator();
    }

}
