// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.parser.fence;

import java.io.Serializable;
import org.modelcc.language.syntax.Constraints;

/**
 * Fence Constraint Enforcer
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class FenceConstraintEnforcer implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Perform syntactical analysis on a lexical graph.
     * @param constraints the constraints.
     * @param pg the input parsed graph.
     * @return a syntactic analysis graph.
     */
    public SyntaxGraph enforce(Constraints constraints, ParsedGraph pg) {
        FenceConstraintEnforcerSafe fces = new FenceConstraintEnforcerSafe();
        return fces.enforce(constraints, pg);
    }

}
