// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.parser.fence;

import java.io.Serializable;
import org.modelcc.lexer.lamb.LexicalGraph;
import org.modelcc.language.syntax.SyntacticSpecification;

/**
 * Fence - SyntaxGraphParser with Lexical and Syntactic Ambiguity Support.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class Fence implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Perform syntactical analysis on a Lexical Graph.
     * @param fs the Fence specification.
     * @param lg the input lexical graph.
     * @return a syntax graph.
     */
    public SyntaxGraph parse(SyntacticSpecification fs,LexicalGraph lg) {
        FenceGrammarParser fgp = new FenceGrammarParser();
        ParsedGraph pg = fgp.parse(fs.getGrammar(),lg);
        FenceConstraintEnforcer fce = new FenceConstraintEnforcer();
        SyntaxGraph sg = fce.enforce(fs.getConstraints(),pg);
        return sg;
    }

}
