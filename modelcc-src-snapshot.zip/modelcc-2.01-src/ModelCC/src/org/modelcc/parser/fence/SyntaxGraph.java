// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.parser.fence;

import java.io.Serializable;
import java.util.Collections;
import java.util.Set;

/**
 * Syntax graph.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public final class SyntaxGraph implements Serializable {

    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * Set of symbols used in this graph.
     */
    private Set<Symbol> symbols;

    /**
     * Set of roots symbols of this graph.
     */
    private Set<Symbol> roots;

    /**
     * Default constructor.
     * @param symbols the symbols used in this graph.
     * @param roots the roots symbols of this graph.
     */
    public SyntaxGraph(Set<Symbol> symbols,Set<Symbol> roots) {
        this.symbols = symbols;
        this.roots = roots;
    }

    /**
     * @return the roots symbols of this graph.
     */
    public Set<Symbol> getRoots() {
        return Collections.unmodifiableSet(roots);
    }

    /**
     * @return the symbols used in this graph.
     */
    public Set<Symbol> getSymbols() {
        return Collections.unmodifiableSet(symbols);
    }

}
