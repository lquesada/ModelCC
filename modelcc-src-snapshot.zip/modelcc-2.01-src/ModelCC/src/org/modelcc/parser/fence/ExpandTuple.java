// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.parser.fence;

import java.io.Serializable;
import java.util.List;
import org.modelcc.language.syntax.Rule;

/**
 * Expand Tuple.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public class ExpandTuple implements Serializable {
    
    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    /**
     * The rule.
     */
    private Rule r;
    
    /**
     * The relevant rule.
     */
    private Rule relevant;
    
    /**
     * The list of symbols.
     */
    private List<ParsedSymbol> symbols;

    public ExpandTuple(Rule r,List<ParsedSymbol> symbols) {
        this.r = r;
        this.symbols = symbols;
        this.relevant = null;
    }

    /**
     * @return the rule
     */
    public Rule getRule() {
        return r;
    }

    /**
     * @return the symbols
     */
    public List<ParsedSymbol> getSymbols() {
        return symbols;
    }
    
    /**
     * @return the relevant rule.
     */
    public Rule getRelevant() {
        return relevant;
    }

    /**
     * @param relevant the relevant to set
     */
    public void setRelevant(Rule relevant) {
        this.relevant = relevant;
    }

    
}
