// ModelCC: Model-Based Compiler Compiler.
// Version 2.01 (2012-01-18).
//
// Requires JRE 5 or higher.
//
// Distributed under ModelCC Shared Software License.
// www.modelcc.org / info@modelcc.org
//
// ModelCC development team:
//
// - Luis Quesada (lquesada@modelcc.org).
// - Fernando Berzal (berzal@modelcc.org).
// - Francisco J. Cortijo (cb@modelcc.org).
// - Juan-Carlos Cubero (jc.cubero@modelcc.org).



package org.modelcc.types;

import java.io.Serializable;

/**
 * Scientific Notation Parser.
 * @author Luis Quesada (lquesada@modelcc.org)
 * @serial
 */
public class ScientificNotationParser implements Serializable {
    
    /**
     * Serial Version ID
     */
    private static final long serialVersionUID = 454100201L;

    private ScientificNotationParser() {
        
    }
        
    public static double parseReal(String text) {
        int pos = -1;
        pos = text.indexOf('e');
        if (pos == -1)
            pos = text.indexOf('E');
        
        String m;
        String e;
        if (pos != -1) {
            m = text.substring(0,pos);
            e = text.substring(pos+1);
        }
        else {
            m = text;
            e = "0";
        }
        if (m.charAt(0)=='+')
            m = m.substring(1);
        if (e.charAt(0)=='+')
            e = e.substring(1);
        double ret = Double.parseDouble(m)*Math.pow(10, Double.parseDouble(e));
        return ret;
    }
}
